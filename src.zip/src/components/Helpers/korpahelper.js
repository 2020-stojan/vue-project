import Vue from 'vue'

export const korpa = new Vue();